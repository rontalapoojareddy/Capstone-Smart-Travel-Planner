import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';

const app = express();
const PORT = 3000;

// Middleware setup
app.use(cors());
app.use(bodyParser.json());

// Handle form data submission from the travel form
app.post('/generate-travel-plan', (req, res) => {
    const userDetails = req.body;
    
    // Placeholder logic for generating a travel plan
    const travelPlan = {
        itinerary: [
            { day: 1, activity: "Visit popular landmarks in " + userDetails.destination },
            { day: 2, activity: "Experience local cuisine and shopping" },
            { day: 3, activity: "Day trip to nearby scenic spots" },
        ],
        recommendations: ["Pack lightly", "Bring local currency", "Try local foods"],
        moodBasedSuggestion: userDetails.mood === "relaxing" ? "Beach day!" : "City exploration",
    };

    // Send the travel plan back to the frontend
    res.json({ travelPlan });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
