// Smooth Scroll for navigation links
document.querySelectorAll('.scroll-link').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        document.getElementById(targetId).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Profile Dropdown Toggle
const profileLink = document.querySelector('.profile-link');
const dropdownMenu = document.querySelector('.dropdown');

profileLink.addEventListener('click', (e) => {
    e.preventDefault();
    dropdownMenu.classList.toggle('show');
});

// Close dropdown if clicking outside
document.addEventListener('click', (e) => {
    if (!profileLink.contains(e.target) && !dropdownMenu.contains(e.target)) {
        dropdownMenu.classList.remove('show');
    }
});
// Smooth Scroll for navigation links
document.querySelectorAll('.scroll-link').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        document.getElementById(targetId).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Image Gallery Hover and Modal Popup
const images = document.querySelectorAll('.image-gallery img');
images.forEach(img => {
    img.addEventListener('mouseover', () => {
        img.style.transform = 'scale(1.1)';
    });
    img.addEventListener('mouseout', () => {
        img.style.transform = 'scale(1)';
    });

    // Modal Popup on click
    img.addEventListener('click', () => {
        const modal = document.createElement('div');
        modal.classList.add('modal');
        const modalImg = document.createElement('img');
        modalImg.src = img.src;
        modalImg.classList.add('modal-image');
        modal.appendChild(modalImg);
        document.body.appendChild(modal);

        modal.addEventListener('click', () => {
            modal.remove();
        });
    });
});
// Minimum length validation for username and password
document.querySelector("form").addEventListener("submit", function (event) {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username.length < 5) {
        alert("Username must be at least 5 characters long.");
        event.preventDefault();
    } else if (password.length < 6) {
        alert("Password must be at least 6 characters long.");
        event.preventDefault();
    }
});

// Password visibility toggle
const passwordField = document.getElementById("password");
const toggleButton = document.createElement("button");
toggleButton.type = "button";
toggleButton.textContent = "Show";
toggleButton.style.marginTop = "10px";
toggleButton.onclick = () => {
    if (passwordField.type === "password") {
        passwordField.type = "text";
        toggleButton.textContent = "Hide";
    } else {
        passwordField.type = "password";
        toggleButton.textContent = "Show";
    }
};

// Add the toggle button after the password field
passwordField.parentNode.insertBefore(toggleButton, passwordField.nextSibling);
// Password confirmation check
document.querySelector("form").addEventListener("submit", function (event) {
    const password = document.getElementById("new-password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        event.preventDefault(); // Prevent form submission
    }
});

// Password strength feedback
const passwordInput = document.getElementById("new-password");
const strengthMessage = document.createElement("p");
strengthMessage.style.color = "red";
passwordInput.parentNode.insertBefore(strengthMessage, passwordInput.nextSibling);

passwordInput.addEventListener("input", function () {
    const passwordValue = passwordInput.value;
    if (passwordValue.length < 6) {
        strengthMessage.textContent = "Password is too weak.";
    } else if (passwordValue.length < 10) {
        strengthMessage.textContent = "Password is moderate.";
        strengthMessage.style.color = "orange";
    } else {
        strengthMessage.textContent = "Password is strong!";
        strengthMessage.style.color = "green";
    }
});
// Set a countdown timer for redirection
let countdown = 10; // 10-second countdown
const countdownDisplay = document.createElement("p");
countdownDisplay.textContent = `Redirecting to the homepage in ${countdown} seconds...`;
document.querySelector("main").appendChild(countdownDisplay);

const countdownInterval = setInterval(() => {
    countdown--;
    countdownDisplay.textContent = `Redirecting to the homepage in ${countdown} seconds...`;

    // Redirect when countdown reaches 0
    if (countdown === 0) {
        clearInterval(countdownInterval);
        window.location.href = "index.html";
    }
}, 1000);

// Optional: Cancel auto-redirect if the user clicks the "Back to Home" button
document.querySelector("button").addEventListener("click", () => {
    clearInterval(countdownInterval); // Stop countdown
    window.location.href = "index.html"; // Immediate redirect
});
